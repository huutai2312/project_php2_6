<?php

namespace App\controller;

use App\model\Order;

class AdminOrdersController extends Controller
{
    // public function adminOrders()
    // {
    //     session_start();
    //     $this->importHeader();
    //     $orderModel = new Order();
    //     $orders = $orderModel->getAllOrders();
    //     include "../project_php2_5/app/view/admin/orders.php";
    //     $this->importFooter();
    // }
}
